<h1>KrakenKat</h1>
<h3>
  An experimental addon extension to FireFox that adds my kitten Vincent to your web browser
</h3>
<h3>
  He get's to do all of his crazy cat-like things c:
</h3>
<br>
<hr>
<br>
<h2><a href="https://addons.mozilla.org/en-US/firefox/addon/krakenkat/" target="_blank">Click here to Download Extension</a> (FireFox Only)</h2>
